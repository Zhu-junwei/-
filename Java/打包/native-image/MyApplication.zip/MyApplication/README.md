使用GraalVM构建本地镜像

https://docs.spring.io/spring-boot/docs/current/reference/html/native-image.html#native-image
